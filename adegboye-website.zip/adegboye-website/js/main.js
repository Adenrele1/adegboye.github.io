(function(){var s=document.getElementById('qr'),o='',v=11;
function z(x,y){return (x<6&&y<6)||(x>6&&y<6)||(x<6&&y>6)}
[[0,0],[8,0],[0,8]].forEach(function(p){o+='<rect x="'+p[0]+'" y="'+p[1]+'" width="5" height="5" fill="currentColor"/><rect x="'+(p[0]+1)+'" y="'+(p[1]+1)+'" width="3" height="3" fill="var(--surface)"/><rect x="'+(p[0]+2)+'" y="'+(p[1]+2)+'" width="1" height="1" fill="currentColor"/>'});
for(var y=0;y<13;y++)for(var x=0;x<13;x++){v=(v*1103515245+12345)&0x7fffffff;if(!z(x,y)&&((v>>>16)&1))o+='<rect x="'+x+'" y="'+y+'" width="1" height="1" fill="currentColor"/>'}
s.innerHTML=o})();
