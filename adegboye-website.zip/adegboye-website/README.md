# Adenrele Olalekan Adegboye - personal website

Static site (HTML, CSS, JavaScript). No build step.

## Publish on GitHub Pages
1. Create a new public repository named `YOUR-USERNAME.github.io`.
2. Upload everything in this folder to the repository root (keep the `css`, `js` and `images` folders).
3. Open Settings > Pages and choose "Deploy from a branch", branch `main`, folder `/ (root)`.
4. After a minute or two the site is live at `https://YOUR-USERNAME.github.io`.

## Edit
- Text and sections: `index.html`
- Colours, fonts, layout: `css/style.css`
- Photo: replace `images/adegboye.jpg` (keep the same file name)
